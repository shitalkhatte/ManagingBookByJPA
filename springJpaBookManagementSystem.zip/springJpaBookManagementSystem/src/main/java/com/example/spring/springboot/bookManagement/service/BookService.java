package com.example.spring.springboot.bookManagement.service;

import java.util.List;

import com.example.spring.springboot.bookManagement.Entity.Book;

public interface BookService
{
	List<Book> getAllBooks();
	Book getBookById(int id);
	Book saveBook(Book b);
	void deleteBookById(int id);
}
