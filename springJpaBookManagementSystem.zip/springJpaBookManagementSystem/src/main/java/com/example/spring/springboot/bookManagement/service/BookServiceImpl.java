package com.example.spring.springboot.bookManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.spring.springboot.bookManagement.Entity.Book;
import com.example.spring.springboot.bookManagement.Repository.BookRepository;
@Component
public class BookServiceImpl implements BookService 
{
	@Autowired
	BookRepository bookRepository;

	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public Book getBookById(int id) {
		Book b= bookRepository.findById(id).orElse(null);
		return b;
	}

	@Override
	public Book saveBook(Book b) {
		return bookRepository.save(b);
	}

	@Override
	public void deleteBookById(int id) {
		bookRepository.deleteById(id);
	}

}
