package com.example.spring.springboot.bookManagement.Entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="book")
public class Book 
{
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Id
	private int id;
	@Column(name="title")
	private String title;
	@Column(name="author")
	private String author;
	@Column(name="price")
	private double price;
	@Column(name="publicationDate")
	private LocalDate publicationDate;
	
	public Book(int id, String title, String author, double price, LocalDate publicationDate) 
	{
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		this.price = price;
		this.publicationDate = publicationDate;
	}
	
	public Book(String title, String author, double price, LocalDate publicationDate) 
	{
		this.title = title;
		this.author = author;
		this.price = price;
		this.publicationDate = publicationDate;
	}
	
	public Book() 
	{
	}

	@Override
	public String toString() 
	{
		return "id=" + id + "\ntitle=" + title + "\nauthor=" + author + "\nprice=" + price + "\npublicationDate="
				+ publicationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDate getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(LocalDate publicationDate) {
		this.publicationDate = publicationDate;
	}	
}
